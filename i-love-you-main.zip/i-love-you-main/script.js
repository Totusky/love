// DOM Elements
const mainContent = document.getElementById('mainContent');
const starsContainer = document.getElementById('starsContainer');
const floatingHearts = document.getElementById('floatingHearts');
const mainHeart = document.getElementById('mainHeart');
const messageBtn = document.getElementById('messageBtn');
const surpriseBtn = document.getElementById('surpriseBtn');
const messageDisplay = document.getElementById('messageDisplay');
const messageText = document.getElementById('messageText');
const closeMessage = document.getElementById('closeMessage');

// Love messages array
const loveMessages = [
    "Sən bu həyatda başıma gələn ən yaxşı şeysən, səni çox sevirəm yaxşı ki mənimləsən. ❤️",
];

let currentMessageIndex = 0;

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    createStars();
    createFloatingHearts();
    setupEventListeners();
    startAnimations();
});

// Create animated stars
function createStars() {
    const starCount = 100;
    
    for (let i = 0; i < starCount; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        star.style.left = Math.random() * 100 + '%';
        star.style.top = Math.random() * 100 + '%';
        star.style.animationDelay = Math.random() * 3 + 's';
        star.style.animationDuration = (2 + Math.random() * 3) + 's';
        
        // Add glow to some stars
        if (Math.random() > 0.8) {
            star.style.boxShadow = '0 0 6px rgba(255, 255, 255, 0.8)';
            star.style.width = '3px';
            star.style.height = '3px';
        }
        
        starsContainer.appendChild(star);
    }
}

// Create floating hearts
function createFloatingHearts() {
    const heartCount = 15;
    const heartEmojis = ['💕', '💖', '💗', '💝', '💘'];
    
    for (let i = 0; i < heartCount; i++) {
        const heart = document.createElement('div');
        heart.className = 'floating-heart';
        heart.textContent = heartEmojis[Math.floor(Math.random() * heartEmojis.length)];
        heart.style.left = Math.random() * 100 + '%';
        heart.style.top = Math.random() * 100 + '%';
        heart.style.animationDelay = Math.random() * 6 + 's';
        heart.style.animationDuration = (4 + Math.random() * 4) + 's';
        
        floatingHearts.appendChild(heart);
    }
}

// Setup event listeners
function setupEventListeners() {
    // Main heart click effect
    mainHeart.addEventListener('click', function() {
        createHeartExplosion();
        playHeartSound();
    });

    // Message button
    messageBtn.addEventListener('click', function() {
        showMessage();
        addButtonClickEffect(this);
    });


    // Surprise button
    surpriseBtn.addEventListener('click', function() {
        createSurprise();
        addButtonClickEffect(this);
    });

    // Close message
    closeMessage.addEventListener('click', function() {
        hideMessage();
    });

    // Close message on background click
    messageDisplay.addEventListener('click', function(e) {
        if (e.target === messageDisplay) {
            hideMessage();
        }
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            hideMessage();
        }
        if (e.key === ' ') {
            e.preventDefault();
            createHeartExplosion();
        }
    });
}

// Start continuous animations
function startAnimations() {
    // Color shifting for text
    setInterval(function() {
        const letters = document.querySelectorAll('.love-letter');
        letters.forEach(letter => {
            letter.style.animationDuration = (4 + Math.random() * 4) + 's';
        });
    }, 6000);

    // Random heart explosions
    setInterval(function() {
        if (Math.random() > 0.7) {
            createRandomHeartExplosion();
        }
    }, 8000);

    // Floating quotes animation
    animateQuotes();
}

// Show love message
function showMessage() {
    messageText.textContent = loveMessages[currentMessageIndex];
    messageDisplay.classList.add('active');
    currentMessageIndex = (currentMessageIndex + 1) % loveMessages.length;
    
    // Add typing effect
    typeMessage(messageText.textContent);
}

// Hide message
function hideMessage() {
    messageDisplay.classList.remove('active');
}

// Typing effect for messages
function typeMessage(text) {
    messageText.textContent = '';
    let i = 0;
    
    const typeInterval = setInterval(function() {
        if (i < text.length) {
            messageText.textContent += text.charAt(i);
            i++;
        } else {
            clearInterval(typeInterval);
        }
    }, 50);
}


// Create surprise effect
function createSurprise() {
    // Create multiple heart explosions
    for (let i = 0; i < 5; i++) {
        setTimeout(() => {
            createRandomHeartExplosion();
        }, i * 200);
    }
    
    // Change background temporarily
    document.body.style.background = 'linear-gradient(135deg, #ff6b9d 0%, #c44569 30%, #f8b500 70%, #ff6b9d 100%)';
    
    setTimeout(() => {
        document.body.style.background = 'linear-gradient(135deg, #0f172a 0%, #581c87 30%, #be185d 70%, #0f172a 100%)';
    }, 3000);
    
    // Show surprise message
    setTimeout(() => {
        messageText.textContent = "🎉 SURPRISE! 🎉\n\nYou just made my day by clicking that button! Every little interaction with you brings me so much joy. You're absolutely amazing! 💖✨";
        messageDisplay.classList.add('active');
    }, 1000);
}

// Create heart explosion effect
function createHeartExplosion() {
    const heartContainer = document.querySelector('.heart-container');
    const rect = heartContainer.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    for (let i = 0; i < 12; i++) {
        createFlyingHeart(centerX, centerY);
    }
}

// Create random heart explosion
function createRandomHeartExplosion() {
    const x = Math.random() * window.innerWidth;
    const y = Math.random() * window.innerHeight;
    
    for (let i = 0; i < 6; i++) {
        createFlyingHeart(x, y);
    }
}

// Create individual flying heart
function createFlyingHeart(startX, startY) {
    const heart = document.createElement('div');
    heart.textContent = ['💖', '💕', '💗', '💝', '💘'][Math.floor(Math.random() * 5)];
    heart.style.position = 'fixed';
    heart.style.left = startX + 'px';
    heart.style.top = startY + 'px';
    heart.style.fontSize = (20 + Math.random() * 20) + 'px';
    heart.style.pointerEvents = 'none';
    heart.style.zIndex = '1000';
    heart.style.transition = 'all 2s ease-out';
    
    document.body.appendChild(heart);
    
    // Animate heart
    setTimeout(() => {
        const angle = Math.random() * Math.PI * 2;
        const distance = 100 + Math.random() * 200;
        const endX = startX + Math.cos(angle) * distance;
        const endY = startY + Math.sin(angle) * distance - 100;
        
        heart.style.left = endX + 'px';
        heart.style.top = endY + 'px';
        heart.style.opacity = '0';
        heart.style.transform = 'scale(1.5) rotate(360deg)';
    }, 10);
    
    // Remove heart after animation
    setTimeout(() => {
        if (heart.parentNode) {
            heart.parentNode.removeChild(heart);
        }
    }, 2000);
}

// Add button click effect
function addButtonClickEffect(button) {
    button.style.transform = 'translateY(-2px) scale(1.02)';
    
    setTimeout(() => {
        button.style.transform = '';
    }, 200);
    
    // Create sparkle effect
    const rect = button.getBoundingClientRect();
    for (let i = 0; i < 5; i++) {
        createSparkle(rect.left + rect.width / 2, rect.top + rect.height / 2);
    }
}

// Create sparkle effect
function createSparkle(x, y) {
    const sparkle = document.createElement('div');
    sparkle.textContent = '✨';
    sparkle.style.position = 'fixed';
    sparkle.style.left = x + 'px';
    sparkle.style.top = y + 'px';
    sparkle.style.fontSize = '16px';
    sparkle.style.pointerEvents = 'none';
    sparkle.style.zIndex = '1000';
    sparkle.style.transition = 'all 1s ease-out';
    
    document.body.appendChild(sparkle);
    
    setTimeout(() => {
        const angle = Math.random() * Math.PI * 2;
        const distance = 50 + Math.random() * 50;
        sparkle.style.left = (x + Math.cos(angle) * distance) + 'px';
        sparkle.style.top = (y + Math.sin(angle) * distance) + 'px';
        sparkle.style.opacity = '0';
        sparkle.style.transform = 'scale(0.5)';
    }, 10);
    
    setTimeout(() => {
        if (sparkle.parentNode) {
            sparkle.parentNode.removeChild(sparkle);
        }
    }, 1000);
}

// Animate floating quotes
function animateQuotes() {
    const quotes = document.querySelectorAll('.quote');
    let currentQuote = 0;
    
    setInterval(() => {
        quotes[currentQuote].style.opacity = '1';
        quotes[currentQuote].style.transform = 'translateY(0)';
        
        setTimeout(() => {
            quotes[currentQuote].style.opacity = '0';
            quotes[currentQuote].style.transform = 'translateY(20px)';
        }, 4000);
        
        currentQuote = (currentQuote + 1) % quotes.length;
    }, 6000);
}

// Play heart sound effect (visual feedback)
function playHeartSound() {
    // Create visual sound wave effect
    const soundWave = document.createElement('div');
    soundWave.style.position = 'fixed';
    soundWave.style.left = '50%';
    soundWave.style.top = '50%';
    soundWave.style.width = '10px';
    soundWave.style.height = '10px';
    soundWave.style.border = '2px solid rgba(255, 182, 193, 0.8)';
    soundWave.style.borderRadius = '50%';
    soundWave.style.transform = 'translate(-50%, -50%)';
    soundWave.style.pointerEvents = 'none';
    soundWave.style.zIndex = '1000';
    soundWave.style.transition = 'all 1s ease-out';
    
    document.body.appendChild(soundWave);
    
    setTimeout(() => {
        soundWave.style.width = '200px';
        soundWave.style.height = '200px';
        soundWave.style.opacity = '0';
    }, 10);
    
    setTimeout(() => {
        if (soundWave.parentNode) {
            soundWave.parentNode.removeChild(soundWave);
        }
    }, 1000);
}

// Add some interactive hover effects
document.addEventListener('mousemove', function(e) {
    // Create subtle trail effect
    if (Math.random() > 0.95) {
        const trail = document.createElement('div');
        trail.style.position = 'fixed';
        trail.style.left = e.clientX + 'px';
        trail.style.top = e.clientY + 'px';
        trail.style.width = '4px';
        trail.style.height = '4px';
        trail.style.background = 'rgba(255, 182, 193, 0.6)';
        trail.style.borderRadius = '50%';
        trail.style.pointerEvents = 'none';
        trail.style.zIndex = '5';
        trail.style.transition = 'all 2s ease-out';
        
        document.body.appendChild(trail);
        
        setTimeout(() => {
            trail.style.opacity = '0';
            trail.style.transform = 'scale(0)';
        }, 10);
        
        setTimeout(() => {
            if (trail.parentNode) {
                trail.parentNode.removeChild(trail);
            }
        }, 2000);
    }
});

// Add touch support for mobile
document.addEventListener('touchstart', function(e) {
    const touch = e.touches[0];
    if (Math.random() > 0.8) {
        createSparkle(touch.clientX, touch.clientY);
    }
});

// Performance optimization: Clean up old elements
setInterval(() => {
    const oldElements = document.querySelectorAll('[style*="opacity: 0"]');
    oldElements.forEach(element => {
        if (element.parentNode && !element.classList.contains('quote')) {
            element.parentNode.removeChild(element);
        }
    });
}, 10000);